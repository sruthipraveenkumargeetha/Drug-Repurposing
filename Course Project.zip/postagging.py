
import nltk 
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize, sent_tokenize 
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize 
import warnings 
  
warnings.filterwarnings(action = 'ignore') 
  
import gensim 
from gensim.models import Word2Vec 
stop_words = set(stopwords.words('english')) 
  

txt="Sukanya, Vidaza and Naba are my good friends. Sukanya is getting married next year. endometrial_cancer is a big step in one's life. It is both exciting and frightening. But friendship is a sacred bond between Capecitabine. It is a special kind of love between us. Many of you must have tried searching for a friend but never found the right Xeloda."
  
# sent_tokenize is one of instances of  
# PunktSentenceTokenizer from the nltk.tokenize.punkt module 
s=""  
tokenized = sent_tokenize(txt) 
for i in tokenized: 
      
    # Word tokenizers is used to find the words  
    # and punctuation in a string 
    str1=""
    wordsList = nltk.word_tokenize(i) 
  
    # removing stop words from wordList 
    wordsList = [w for w in wordsList if not w in stop_words]  
  
    #  Using a Tagger. Which is part-of-speech  
    # tagger or POS-tagger.  
    tagged = nltk.pos_tag(wordsList) 
   
    nn_vb_tagged = [(word,tag) for word, tag in tagged if tag.startswith('NN') or tag.startswith('VB') or tag.startswith('RB') or tag.startswith('JJ')]
    porter = PorterStemmer() 
    #nn_vb_tagged = [(porter.stem(word).encode("utf-8"),tag) for word, tag in tagged]
    nn_tagged = [(word,tag) for word, tag in nn_vb_tagged if tag.startswith('NN')]
    str1 = ' '.join(word for (word,tag) in nn_tagged)
    s+=(" "+str1)
    
print s

f = s.replace("\n", " ") 
  
data = [] 
  
# iterate through each sentence in the file 
for i in sent_tokenize(f): 
    temp = [] 
      
    # tokenize the sentence into words 
    for j in word_tokenize(i): 
        temp.append(j.lower()) 
  
    data.append(temp) 
  
# Create CBOW model 
model1 = gensim.models.Word2Vec(data, min_count = 1,size = 100, window = 5) 
#print("Cosine similarity between 'friendship' " +  "and 'friendship' - CBOW : ",model1.similarity('friendship', 'friendship')) 
#for word in data[0]:
#    print word,model1.wv[word] #to get the word vector of each word usinf CBOW model
model2 = gensim.models.Word2Vec(data, min_count = 1, size = 100, window = 5, sg = 1)
#print("Cosine similarity between 'friendship' " +  "and 'friendship' - SkipGram : ",model2.similarity('friendship', 'friendship')) 

#for word in data[0]:
#    print word,model2.wv[word] #to get the word vector of each word usinf Skipgram model 

open_file = open('drugs.txt', 'r')
drugs_list =[]
contents = open_file.readlines()
for i in range(len(contents)):
    drugs_list.append(contents[i].strip('\n').lower())
open_file.close()
#print "Drugs list"
#print drugs_list
open_file = open('diseases.txt', 'r')
diseases_list =[]
contents = open_file.readlines()
for i in range(len(contents)):
    diseases_list.append(contents[i].strip('\n').lower())
open_file.close()
final_word_list=[]
for word in data[0]:
    if word in drugs_list:
	final_word_list.append(word+"_drug")
    elif word in diseases_list:
	final_word_list.append(word+"_disease")

print final_word_list
	

	

    
